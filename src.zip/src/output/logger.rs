#[allow(dead_code)]
pub fn log_info(msg: &str) {
    println!("[INFO] {}", msg);
}
