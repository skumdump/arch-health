pub fn run_check(format: &str) {
    if format == "text" {
        println!("✅ [pacman] Package DB integrity OK");
    }
}
